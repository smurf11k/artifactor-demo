package com.renata.demoartifactor.domain.exception;

public class DependencyException extends RuntimeException {

    public DependencyException(String message) {
        super(message);
    }
}
