package com.renata.demoartifactor.domain.exception;

public class SignUpException extends RuntimeException {

    public SignUpException(String message) {
        super(message);
    }
}
