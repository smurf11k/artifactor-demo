package com.renata.demoartifactor.appui;

import java.io.IOException;

public interface Renderable {

    void render() throws IOException;
}
